package com.webcorestone.DMS.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.webcorestone.DMS.model.DoctorDetails;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.model.LoginDetails;
import com.webcorestone.DMS.model.NursDetails;
import com.webcorestone.DMS.model.StudentDetails;
import com.webcorestone.DMS.serviceI.DoctorServiceI;
import com.webcorestone.DMS.serviceI.EmployeeServiceI;
import com.webcorestone.DMS.serviceI.LoginService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/Employee")
public class EmployeeController 
{
	
	@Autowired
	EmployeeServiceI hs;
	
	
	
	@GetMapping(value="/logd/{loginUserName}/{loginPassword}")
	 public EmployeeDetails logincheck(@PathVariable("loginUserName") String loginUserName , @PathVariable("loginPassword") String loginPassword, Model m) throws JsonProcessingException 
	  { 
		 // List<LoginDetails> l=new ArrayList<LoginDetails>();
		  LoginDetails l1= hs.singleLogin(loginUserName,loginPassword);	  
			
			 System.out.println(l1.getLoginPassword());
		         int emp_id=l1.getLoginId();
		         
			EmployeeDetails e=new EmployeeDetails();
		       
			 e=hs.singleEmployee(emp_id);
			return e;			 
		  
	  }
	
	
	@PostMapping("/register")
			public void savedataEmployee(@RequestBody EmployeeDetails e)
			
			{
		System.out.println(e.getEmployeeFirstName());
				EmployeeDetails id=hs.savedata(e);
				
				
					//return "Employee Record Added";
			}
	
	          @GetMapping("/getallemployee")
	                public List<EmployeeDetails> GetEmployee()
	        {
		
		             List<EmployeeDetails> d = hs.ShowEmployee();
		                     
				return d;
	        	
	        }
		  
		  
                 @DeleteMapping("/delete/{employeeid}")
				public int deleteEmp(@PathVariable int employeeid) {
					int i = hs.deleteEmp(employeeid);
					return i;
				}
			  
			  @GetMapping(value = "/singledataEmp/{employeeid}")
				public EmployeeDetails getSingleEmployee(@PathVariable int employeeid) {
					EmployeeDetails d = hs.getSingleEmployee(employeeid);
					return d;
				}
		  
			  @PutMapping(value ="/update")
				public  List<EmployeeDetails> updateEmp(@RequestBody EmployeeDetails employee) {
					List<EmployeeDetails> d = hs.updateEmp(employee);
					return d;
				}
		  
	//	------------DOCTOR-----------------  
			  
			  @GetMapping("/getAllDoctor")
              public List<DoctorDetails> GetDoctor()
      {
	
	             List<DoctorDetails> dd = hs.ShowDoctor();
	                     
			return dd;
      	
      }

		  @PostMapping(value = "/registerdoctor")
			public String saveDoctordata(@RequestBody DoctorDetails d)
			
			{
				DoctorDetails dd=hs.savedata(d);
				
				System.out.println(dd.getDoctorFirstName());
					return "Added Doctor Successfully";
			}
		  @DeleteMapping("/DeleteDoctor/{doctorId}")
			public int deleteDoctor(@PathVariable int doctorId) {
				int i = hs.delete1(doctorId);
				return i;
			}
		
		 
		 @GetMapping(value = "/singledatadoctor/{doctorId}")
			public DoctorDetails getSingleDoctor(@PathVariable int doctorId) {
				DoctorDetails d = hs.getSingleDoctor(doctorId);
				return d;
			}

		@PutMapping(value = "/UpdateDoctor")
			public  List<DoctorDetails> updateDoctor(@RequestBody DoctorDetails doctor) {
				List<DoctorDetails> d = hs.update(doctor);
				return d;
			}
		 
//*******************************Nurse Details**************************************
		
		
		 @GetMapping("/getAllNurse")
         public List<NursDetails> GetNurse()
		 {

			 List<NursDetails> nd = hs.ShowNurs();
             return nd;

		 }
             @PostMapping(value = "/registernurse")
			public String savedataNurse(@RequestBody NursDetails n)
			
			{
				NursDetails nd=hs.savedataNurse(n);
				
				System.out.println(nd.getNursFirstName());
					return "Added Nurse Successfully";
			}
		  @DeleteMapping("/DeleteNurse/{nursId}")
			public int deleteNurse(@PathVariable int nursId) {
				int i = hs.deleteNurse(nursId);
				return i;
			}
		
		 
		 @GetMapping(value = "/singlenurse/{nursId}")
			public NursDetails getSingleNurse(@PathVariable int nursId) {
				NursDetails nd = hs.getSingleNurse(nursId);
				return nd;
			}

		@PutMapping(value = "/UpdateNurse")
			public  List<NursDetails> updateNurse(@RequestBody NursDetails nurse) {
				List<NursDetails> nd = hs.update(nurse);
				return nd;
			}
		 
	 
		//*******************************Student Details**************************************
		
		 @GetMapping("/getAllStudent")
                public List<StudentDetails> GetStudent()
        {

            List<StudentDetails> sd = hs.ShowStudent();
                    
		return sd;
 	
        }

		 @PostMapping(value="/registerstudent")
			public String savedataStudent(@RequestBody StudentDetails s)
			
			{
				StudentDetails sd=hs.savedataStudent(s);
				
				System.out.println(sd.getFirstName());
					return "Added Student Successfully";
			}
		    @DeleteMapping("/DeleteStudent/{id}")
			public int deletestudent(@PathVariable int id) {
				int i = hs.deleteStudent(id);
				return i;
			}
		
		 
		 @GetMapping(value = "/SingleStudent/{id}")
			public StudentDetails getSingleStudent(@PathVariable int id) {
				StudentDetails sd = hs.getSingleStudent(id);
				return sd;
			}

		@PutMapping(value ="/UpdateStudent")
			public  List<StudentDetails> updateStudent(@RequestBody StudentDetails student) {
				List<StudentDetails> nd = hs.UpdateStudent(student);
				return nd;
			}
		 
			
		  
	


}
