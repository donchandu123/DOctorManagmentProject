package com.webcorestone.DMS.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webcorestone.DMS.daoI.LoginDao;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.serviceI.LoginService;


	

