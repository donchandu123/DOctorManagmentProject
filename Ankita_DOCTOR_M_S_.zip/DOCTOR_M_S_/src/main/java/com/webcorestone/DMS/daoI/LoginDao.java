package com.webcorestone.DMS.daoI;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.model.LoginDetails;

@Repository
public interface LoginDao extends JpaRepository<LoginDetails, Integer>
{

	@Query("from LoginDetails where loginUserName=:loginUserName and loginPassword=:loginPassword")
	LoginDetails findAllByloginUserNameAndloginPassword(String loginUserName, String loginPassword);

}
