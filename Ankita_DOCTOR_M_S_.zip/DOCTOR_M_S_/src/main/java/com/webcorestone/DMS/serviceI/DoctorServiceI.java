package com.webcorestone.DMS.serviceI;

import java.util.List;

import com.webcorestone.DMS.model.DoctorDetails;

public interface DoctorServiceI 
{

	/*DoctorDetails savedata(DoctorDetails d);

	List<DoctorDetails> getalldata();

	int delete1(int doctorId);

	DoctorDetails getSingleDoctor(int doctorId);

	List<DoctorDetails> update(DoctorDetails doctor);*/
 
}
