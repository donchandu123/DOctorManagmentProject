package com.webcorestone.DMS.serviceI;

import com.webcorestone.DMS.model.EmployeeDetails;

public interface LoginService {

	EmployeeDetails singleemployee(String loginUserName, String loginPassword);

	
}
