package com.webcorestone.DMS.serviceI;

import java.util.List;
import java.util.Optional;

import com.webcorestone.DMS.model.DoctorDetails;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.model.LoginDetails;
import com.webcorestone.DMS.model.NursDetails;
import com.webcorestone.DMS.model.StudentDetails;

public interface EmployeeServiceI 
{
	//************Employee-Details***************
	
	public EmployeeDetails savedata(EmployeeDetails e);
	public List<EmployeeDetails> getalldata();
	
	public int deleteEmp(int employeeid);
	public List<EmployeeDetails> updateEmp(EmployeeDetails employee);
	public EmployeeDetails getSingleEmployee(int employeeid);
	public LoginDetails singleLogin(String loginUserName, String loginPassword);
	public EmployeeDetails singleEmployee(int emp_id);
	
//*************Doctor-Details***************************
	
	public DoctorDetails savedata(DoctorDetails d);
	public int delete1(int doctorId);
	public DoctorDetails getSingleDoctor(int doctorId);
	public List<DoctorDetails> update(DoctorDetails doctor);
	
//******************Nurse-Details******************	
	
	public int deleteNurse(int nursId);
	
	public List<NursDetails> ShowNurs();
	public NursDetails getSingleNurse(int nursId);
	public List<NursDetails> update(NursDetails nurse);
	public NursDetails savedataNurse(NursDetails n);

//*************Student-Details************************
	public StudentDetails savedataStudent(StudentDetails s);
	public int deleteStudent(int id);
	public StudentDetails getSingleStudent(int id);
	public List<StudentDetails> UpdateStudent(StudentDetails student);
	
	List<EmployeeDetails> ShowEmployee();
	public List<DoctorDetails> ShowDoctor();
	public List<StudentDetails> ShowStudent();
	
	
	
	

}
