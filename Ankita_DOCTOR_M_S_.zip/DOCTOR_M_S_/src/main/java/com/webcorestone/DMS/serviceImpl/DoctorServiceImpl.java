package com.webcorestone.DMS.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webcorestone.DMS.daoI.DoctorDaoI;
import com.webcorestone.DMS.model.DoctorDetails;
import com.webcorestone.DMS.serviceI.DoctorServiceI;

@Service
public class DoctorServiceImpl  implements DoctorServiceI{

	
	
}
