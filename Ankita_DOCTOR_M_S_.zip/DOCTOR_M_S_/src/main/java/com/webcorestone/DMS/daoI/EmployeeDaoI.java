package com.webcorestone.DMS.daoI;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.webcorestone.DMS.model.EmployeeDetails;

@Repository
public interface EmployeeDaoI extends JpaRepository<EmployeeDetails, Integer>
{

	//EmployeeDetails findAllByloginUserNameAndloginPassword(String loginUserName, String loginPassword);
	@Query("from EmployeeDetails where login_login_id=:emp_id")
	public EmployeeDetails m1(Integer emp_id);
}
