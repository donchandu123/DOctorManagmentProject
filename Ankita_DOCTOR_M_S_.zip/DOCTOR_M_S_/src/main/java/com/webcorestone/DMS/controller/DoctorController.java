package com.webcorestone.DMS.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.webcorestone.DMS.model.DoctorDetails;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.serviceI.DoctorServiceI;

@RestController
//@RequestMapping("/doctor")
public class DoctorController {
/*	@Autowired
	DoctorServiceI ds;

	@PostMapping(value = "/register")
		public String savedata(@RequestBody DoctorDetails d)
		
		{
			DoctorDetails dd=ds.savedata(d);
			
			System.out.println(dd.getDoctorFirstName());
				return "Added Doctor Successfully";
		}
	 @DeleteMapping("/del/{doctorId}")
		public int delete(@PathVariable int doctorId) {
			int i = ds.delete1(doctorId);
			return i;
		}
	
	 
	 @GetMapping(value = "/singledata/{doctorId}")
		public DoctorDetails getSingleDoctor(@PathVariable int doctorId) {
			DoctorDetails d = ds.getSingleDoctor(doctorId);
			return d;
		}

	@PutMapping(value = "/update")
		public  List<DoctorDetails> update1(@RequestBody DoctorDetails doctor) {
			List<DoctorDetails> d = ds.update(doctor);
			return d;
		}
	 
*/
}
