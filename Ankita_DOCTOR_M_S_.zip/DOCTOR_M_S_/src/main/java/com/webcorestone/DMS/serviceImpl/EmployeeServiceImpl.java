package com.webcorestone.DMS.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.webcorestone.DMS.daoI.DoctorDaoI;
import com.webcorestone.DMS.daoI.EmployeeDaoI;
import com.webcorestone.DMS.daoI.LoginDao;
import com.webcorestone.DMS.daoI.NursDaoI;
import com.webcorestone.DMS.daoI.StudentDaoI;
import com.webcorestone.DMS.model.DoctorDetails;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.model.LoginDetails;
import com.webcorestone.DMS.model.NursDetails;
import com.webcorestone.DMS.model.StudentDetails;
import com.webcorestone.DMS.serviceI.EmployeeServiceI;

@Service
public class EmployeeServiceImpl implements EmployeeServiceI  
{
	@Autowired
	EmployeeDaoI ed;
	
	@Autowired
	LoginDao ld;
	@Autowired
DoctorDaoI di;
	
	@Autowired
	NursDaoI ni;
	
	@Autowired
	StudentDaoI si;


	@Override
	public EmployeeDetails savedata(EmployeeDetails e) 
	{
		return ed.save(e);
	}

	@Override
	public List<EmployeeDetails> getalldata() 
	{
		List<EmployeeDetails> l=ed.findAll();
		return l;
	}

	@Override
	public int deleteEmp(int employeeid) {
		ed.deleteById(employeeid);
		return employeeid;
	}

	@Override
	public List<EmployeeDetails> updateEmp(EmployeeDetails employee) {
		 ed.save(employee);
			return ed.findAll();
	}
	@Override
	public EmployeeDetails getSingleEmployee(int employeeid) {
		EmployeeDetails em = ed.findById(employeeid).get();

		return em;
	}


	@Override
	public LoginDetails singleLogin(String loginUserName, String loginPassword) {
		return ld.findAllByloginUserNameAndloginPassword(loginUserName,loginPassword);
	}

	@Override
	public EmployeeDetails singleEmployee(int emp_id) {
		return ed.m1(emp_id);
	}
	

	

	
	//-----------------Doctor-----------------------

	@Override
	public DoctorDetails savedata(DoctorDetails d) {
		return di.save(d);
	}

	@Override
	public int delete1(int doctorId) {
		 di.deleteById(doctorId);
		 return doctorId;
	}

	@Override
	public DoctorDetails getSingleDoctor(int doctorId) {
		DoctorDetails doc = di.findById(doctorId).get();

		return doc;
	}

	@Override
	public List<DoctorDetails> update(DoctorDetails doctor) {
		 di.save(doctor);
			return di.findAll();
	}

	//---------------Nurse-------------------
	@Override
	public int deleteNurse(int nursId) {
		 ni.deleteById(nursId);
		 return nursId;
	}

	@Override
	public NursDetails getSingleNurse(int nursId) {
		NursDetails nur = ni.findById(nursId).get();

		return nur;
	}

	@Override
	public List<NursDetails> update(NursDetails nurse) {
		 ni.save(nurse);
			return ni.findAll();
	}
	
	@Override
	public List<NursDetails> ShowNurs() {
		
		return ni.findAll();
	}

	@Override
	public NursDetails savedataNurse(NursDetails n) {
		return ni.save(n);
	}
	
	//****************Student-Methods****************

	@Override
	public StudentDetails savedataStudent(StudentDetails s) {
		return si.save(s);
	
	}
	
	@Override
	public List<StudentDetails> ShowStudent() {
		return si.findAll();
	}

	@Override
	public int deleteStudent(int id) {
		 si.deleteById(id);
		 return id;
	}

	@Override
	public StudentDetails getSingleStudent(int id) {
		StudentDetails stu = si.findById(id).get();

		return stu;
	}

	@Override
	public List<StudentDetails> UpdateStudent(StudentDetails student) {
		 si.save(student);
			return si.findAll();
	}

	@Override
	public List<EmployeeDetails> ShowEmployee() {
		return ed.findAll();
	}

	@Override
	public List<DoctorDetails> ShowDoctor() {
		return di.findAll();
	}

	

	

	
	
	

}
