package com.webcorestone.DMS.daoI;

import java.util.List;

import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.webcorestone.DMS.model.AdminDetails;

@Repository
public interface AdminDaoI  extends JpaRepository<AdminDetails, Integer>
{
	public List<AdminDetails> findAllByAdminId(int id);



}
