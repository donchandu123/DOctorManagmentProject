package com.webcorestone.DMS.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webcorestone.DMS.daoI.AdminDaoI;
import com.webcorestone.DMS.daoI.FeedbackDaoI;
import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.FeedbackDetails;
import com.webcorestone.DMS.serviceI.FeedBackServiceI;

@Service
public class FeedbackServiceImpl implements FeedBackServiceI{

	
	@Autowired
	FeedbackDaoI fbdao;
	@Override
	public int saveFeedBack(FeedbackDetails feedback) {
		fbdao.save(feedback);
		return 0;
		//return 0;
	}

	@Override
	public List<FeedbackDetails> getAllFeedback() {
		System.out.println("getALLFeedbackData");
		return fbdao.findAll();
		//return null;
	}

	@Override
	public List<FeedbackDetails> getOneFeedback(int id) {
		List<FeedbackDetails> data=fbdao.findAllByFeedbackId(id);
		return data;		
	}

	@Override
	public int deleteFeedback(int id) {
		fbdao.deleteById(id);
		return 1;
		//return 0;
	}

}
