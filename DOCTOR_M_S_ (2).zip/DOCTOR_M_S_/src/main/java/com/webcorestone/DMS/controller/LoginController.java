package com.webcorestone.DMS.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.LoginDetails;
import com.webcorestone.DMS.serviceI.AdminServiceI;
import com.webcorestone.DMS.serviceI.LoginService;
@CrossOrigin("*")
@RestController
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	LoginService loginservice;
	@Autowired
	AdminServiceI adminservice;
 
	@Autowired
	ObjectMapper obj;
	
	
	@PostMapping("/log")
	public LoginDetails loginAdminDetailes(@RequestBody LoginDetails login) throws JsonProcessingException
	{
		System.out.println("IN LOGIN CONTROLLER");
		String un=login.getLoginUserName();
		String pw=login.getLoginPassword();
		System.out.println(un);
		System.out.println(pw);
//		String status=login.getStatus();
//		int role=login.getRole();
		
		try {
		LoginDetails ld=loginservice.loginAdminData(un, pw);
		if(un.equals(ld.getLoginUserName()))
		{
		String user=ld.getLoginUserName();
		String abc=obj.writeValueAsString(ld);
     	return ld;
		}
		}
		catch (Exception e) {
			System.out.println("ID DOESNOT EXIST");
			LoginDetails ad=new LoginDetails();
			ad.setLoginUserName("unaurtharised");
			ad.setLoginPassword("password");
			ad.setStatus("lalalla");
			ad.setRole(1231);
			return ad;
		
	}
		return null;
	}
	}
	
	
	

