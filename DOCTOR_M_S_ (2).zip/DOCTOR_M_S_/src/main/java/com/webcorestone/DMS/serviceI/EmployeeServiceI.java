package com.webcorestone.DMS.serviceI;

import java.util.List;

import com.webcorestone.DMS.model.EmployeeDetails;

public interface EmployeeServiceI {
	
	public List<EmployeeDetails> getAllEmp();
	public int saveEmployee(EmployeeDetails employee);
	public int updateEmployeeDetailes(EmployeeDetails emp);
	public int deleteEmloyee(int id);
	public EmployeeDetails getoneEmp(int id);

}
