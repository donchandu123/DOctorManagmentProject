package com.webcorestone.DMS.serviceI;

import java.util.List;

import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;

import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.EmployeeDetails;

public interface AdminServiceI {

	public int saveAdminDetailes(AdminDetails admin);
	public List<AdminDetails> getAllAdminData();
	public List<AdminDetails> getOneAdminData(int id);
	public int deleteAdminData(int id);
	public AdminDetails editAdminData(int id);
	public int updateAdminData(AdminDetails admin);
	
	//Employee Methords
	
//	public int saveEmployeeDetailes(EmployeeDetails employee);
	
	
}
