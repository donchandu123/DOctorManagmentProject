package com.webcorestone.DMS.serviceImpl;

import org.springframework.stereotype.Service;

@Service
public class NursServiceImpl 
{

}
