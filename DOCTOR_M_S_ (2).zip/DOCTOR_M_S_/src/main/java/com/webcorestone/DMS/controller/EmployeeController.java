package com.webcorestone.DMS.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.serviceI.EmployeeServiceI;

@CrossOrigin("*")
@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeServiceI employeeservice;
	
	@Autowired
	ObjectMapper obj;
	
	@GetMapping("/getemp")
	public List<EmployeeDetails> getAllEmployee()
	{
		List<EmployeeDetails> list=employeeservice.getAllEmp();
		
		return list;
	}
	
	@PutMapping("/UpdateEmp")
	public String employeesave(@RequestBody EmployeeDetails employee)
	{
		int id=employeeservice.updateEmployeeDetailes(employee);
		return null;
	}
	
	@PostMapping("/saveEmp")
	public String saveEmployeeDetailes(@RequestBody EmployeeDetails employee)
	{
		System.out.println("hello in save contROLLER");
		employeeservice.saveEmployee(employee);
		return null;
	}

	@DeleteMapping("/delete/{empid}")
	public List<EmployeeDetails> deleteEmpoloyee(@PathVariable String empid)
	{
		int id=Integer.parseInt(empid);
	employeeservice.deleteEmloyee(id);	
	List<EmployeeDetails>list=employeeservice.getAllEmp();
	return list;
	}
	
	@GetMapping("/getOneEmployee/{employeeId}")
	public EmployeeDetails getOneEmp(@PathVariable String employeeId)
	{
		System.out.println(employeeId);
		int id=Integer.parseInt(employeeId);
		EmployeeDetails ed=employeeservice.getoneEmp(id);
        System.out.println(ed.getEmployeeFirstName());
		return ed;
	}
	
}
