package com.webcorestone.DMS.daoI;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.FeedbackDetails;
@Repository
public interface FeedbackDaoI extends JpaRepository<FeedbackDetails, Integer>{
	public List<FeedbackDetails> findAllByFeedbackId(int id);
}
